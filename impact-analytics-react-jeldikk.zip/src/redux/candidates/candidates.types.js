const CandidateActionTypes = {
    SET_CANDIDATES: 'SET_CANDIDATES',
    SELECT_CANDIDATE: 'SELECT_CANDIDATE',
    REJECT_CANDIDATE: 'REJECT_CANDIDATE'
}

export default CandidateActionTypes;